package vn.edu.iuh.fit.enums;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public enum Privacy {
    PUBLIC,
    FRIENDS,
    ONLY_ME

}
