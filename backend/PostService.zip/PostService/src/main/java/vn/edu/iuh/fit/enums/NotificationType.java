package vn.edu.iuh.fit.enums;

public enum NotificationType {
    POST_LIKE,
    COMMENT,
    FOLLOW,
    SYSTEM_UPDATE,
    MESSAGE,
    POST
}
